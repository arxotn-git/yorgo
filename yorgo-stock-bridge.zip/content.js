(() => {
  'use strict';
  const ORIGIN = 'https://arxotn-git.github.io';
  const PATH = '/yorgo/';
  const REQUEST = 'yorgo-dashboard';
  const RESPONSE = 'yorgo-extension';
  const ALLOWED_ACTIONS = new Set(['YORGO_STOCK_PING', 'YORGO_STOCK_FETCH']);
  const pending = new Set();
  const seen = new Map();
  const ID = /^[A-Za-z0-9_-]{8,96}$/;
  let stockBusy = false;
  const allowedPage = () => window.top === window && location.origin === ORIGIN && location.pathname.startsWith(PATH);
  const reply = (id, result) => {
    if (allowedPage()) window.postMessage({source: RESPONSE, requestId: id, ...result}, ORIGIN);
  };
  window.addEventListener('message', async (event) => {
    if (!allowedPage() || event.source !== window || event.origin !== ORIGIN) return;
    const msg = event.data;
    if (!msg || typeof msg !== 'object' || Array.isArray(msg) || msg.source !== REQUEST || !ID.test(msg.requestId || '') || typeof msg.requestId !== 'string') return;
    if (!ALLOWED_ACTIONS.has(msg.type)) { reply(msg.requestId, {ok: false, status: 'INVALID_ACTION'}); return; }
    const now = Date.now();
    for (const [id, at] of seen) if (now - at > 600000) seen.delete(id);
    // A duplicate must not start a second fetch or create an ambiguous second reply.
    if (pending.has(msg.requestId) || seen.has(msg.requestId)) return;
    if (seen.size >= 1000) { reply(msg.requestId, {ok: false, status: 'RATE_LIMITED'}); return; }
    seen.set(msg.requestId, now);
    if (msg.type === 'YORGO_STOCK_FETCH' && stockBusy) { reply(msg.requestId, {ok: false, status: 'BUSY'}); return; }
    const safe = {source: REQUEST, requestId: msg.requestId, type: msg.type};
    if (msg.type === 'YORGO_STOCK_FETCH') {
      if (!Array.isArray(msg.queries) || msg.queries.length < 1 || msg.queries.length > 35 || msg.queries.some(q => typeof q !== 'string' || !q.trim() || q.length > 120 || /[\u0000-\u001f\u007f]/.test(q))) {
        reply(msg.requestId, {ok: false, status: 'INVALID_QUERIES'}); return;
      }
      safe.queries = msg.queries.map(q => q.trim());
      stockBusy = true;
    }
    pending.add(msg.requestId);
    try {
      const result = await chrome.runtime.sendMessage(safe);
      reply(msg.requestId, result && typeof result === 'object' ? result : {ok: false, status: 'EXTENSION_UNAVAILABLE'});
    } catch (_) {
      reply(msg.requestId, {ok: false, status: 'EXTENSION_UNAVAILABLE', message: 'Reload this page after installing or updating the extension.'});
    } finally {
      pending.delete(msg.requestId);
      if (msg.type === 'YORGO_STOCK_FETCH') stockBusy = false;
    }
  });
})();
