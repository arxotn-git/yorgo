// Executed only on the authorized Coupang Ads dashboard. Reads performance; never changes campaigns.
async function collectAdsDay(date,today) {
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const visible=e=>e&&e.getClientRects().length;
 const buttons=()=>[...document.querySelectorAll('button,[role="button"]')].filter(visible);
 const button=text=>buttons().find(e=>e.innerText.trim()===text||e.getAttribute('aria-label')===text||e.getAttribute('title')===text);
 const wait=async fn=>{const until=Date.now()+18000;while(Date.now()<until){const x=fn();if(x)return x;await sleep(150);}throw Error('광고 화면 로딩 시간 초과');};
 const grid=()=>[...document.querySelectorAll('[role="grid"]')].find(e=>visible(e)&&[...e.querySelectorAll('[role="columnheader"]')].some(h=>h.innerText.trim()==='캠페인 이름'));
 const dateButton=()=>buttons().find(e=>/^\d{4}\.\d{2}\.\d{2}(\s*~\s*\d{4}\.\d{2}\.\d{2})?$/.test(e.innerText.trim()));
 await wait(()=>grid()&&dateButton());
 if(date!==today){
  dateButton().click();await wait(()=>button('적용'));
  const [y,m,d]=date.split('-').map(Number),title=`${y}년 ${m}월 ${d}일`;
  for(let n=0;n<24;n++){
   const cell=[...document.querySelectorAll('td[title]')].find(e=>visible(e)&&e.title===title);
   if(cell){if(cell.querySelector('[aria-disabled="true"]'))throw Error('조회할 수 없는 광고 날짜: '+date);cell.click();await sleep(150);cell.click();break;}
   const prev=button('이전 달 (PageUp)');if(!prev)throw Error('날짜 선택 구조가 변경되었습니다.');prev.click();await sleep(150);
  }
  const apply=button('적용');if(!apply)throw Error('날짜 적용 버튼이 없습니다.');apply.click();
  const label=date.replaceAll('-','.');await wait(()=>dateButton()?.innerText.trim()===label);await sleep(1800);
 }
 const size=document.querySelector('select[aria-label="rows per page"]');
 if(size&&size.value!=='20'){size.value='20';size.dispatchEvent(new Event('change',{bubbles:true}));await sleep(1200);}
 let back=0;while(button('Previous')&&!button('Previous').disabled&&back++<20){button('Previous').click();await sleep(1000);}
 const rows=[],seen=new Set();
 const num=t=>{const clean=String(t).replace(/[,\s원회%]/g,'');if(!/^\d+(\.\d+)?$/.test(clean))return null;return Number(clean);};
 for(let page=0;page<30;page++){
  const g=await wait(grid),heads=[...g.querySelectorAll('[role="columnheader"]')].map(e=>e.innerText.replace(/\s/g,''));
  const col=t=>heads.findIndex(h=>h.includes(t));
  const indexes={name:col('캠페인이름'),spend:col(date===today?'오늘누적광고비':'집행광고비'),sales:col('광고전환매출'),units:col('광고전환판매수'),clicks:col('클릭수'),cvr:col('전환율')};
  if(Object.values(indexes).some(x=>x<0))throw Error('필요한 광고 지표가 없습니다. 광고센터 지표 설정을 확인해주세요.');
  const groups=[...g.querySelectorAll('[role="rowgroup"]')].filter(e=>e.querySelector('[role="gridcell"]'));
  if(!groups.length)throw Error('광고 캠페인 목록이 비어 있습니다.');
  for(const group of groups){
   const cells=[...group.querySelectorAll('[role="gridcell"]')];if(cells.length!==heads.length)throw Error('광고 표 열 개수가 맞지 않습니다.');
   const name=cells[indexes.name].innerText.replace(/^오늘의 Pick\s*/,'').trim();if(!name||seen.has(name))throw Error('캠페인이 중복되거나 페이지가 갱신되지 않았습니다.');seen.add(name);
   const supplier=!!cells[indexes.name].querySelector('img[alt="supplier-hub item badge"]');
   const row={name,supplier,spend:num(cells[indexes.spend].innerText),sales:date===today?null:num(cells[indexes.sales].innerText),units:date===today?null:num(cells[indexes.units].innerText),clicks:date===today?null:num(cells[indexes.clicks].innerText),cvr:date===today?null:num(cells[indexes.cvr].innerText)};
   if(row.spend===null||(date!==today&&Object.values(row).some(v=>v===null)))throw Error('광고 수치를 읽지 못했습니다: '+name);rows.push(row);
  }
  const next=button('Next');if(!next||next.disabled)return {date,rows,partial:date===today,checkedAt:new Date().toISOString()};
  next.click();await sleep(1400);
 }
 throw Error('광고 캠페인 페이지 한도 초과');
}
