importScripts('ads-collector.js');
'use strict';

const SITE_ORIGIN = 'https://arxotn-git.github.io';
const API_URL = 'https://advertising.coupang.com/marketing/cmg-api/vendoritems';
const LOGIN_URL = 'https://advertising.coupang.com/marketing/campaign/registration?goalType%3DSALES&_cap_client=SUPPLIERHUB';
const LIMITS = Object.freeze({maxQueries: 35, pageSize: 5, maxPagesPerQuery: 40, maxPagesTotal: 350, maxProductsTotal: 1750, maxDurationMs: 230000, fetchTimeoutMs: 15000, maxResponseBytes: 1000000});
let busy = false;
let lastStarted = 0;
let loginTabId = null;

class StockError extends Error {
  constructor(code) { super(code); this.code = code; }
}
function validSender(sender) {
  try {
    const url = new URL(sender.url);
    return sender.id === chrome.runtime.id && sender.frameId === 0 && Number.isInteger(sender.tab?.id) && url.origin === SITE_ORIGIN && url.pathname.startsWith('/yorgo/') && (!sender.origin || sender.origin === SITE_ORIGIN);
  } catch (_) { return false; }
}
function validQueries(queries) {
  return Array.isArray(queries) && queries.length >= 1 && queries.length <= LIMITS.maxQueries && queries.every(q => typeof q === 'string' && q.trim().length > 0 && q.length <= 120 && !/[\u0000-\u001f\u007f]/.test(q));
}
function nonnegativeInteger(value) {
  if (typeof value === 'string' && /^\d{1,15}$/.test(value)) value = Number(value);
  return Number.isSafeInteger(value) && value >= 0 ? value : null;
}
function productId(value) {
  if (typeof value === 'number') return Number.isSafeInteger(value) && value > 0 ? String(value) : null;
  return typeof value === 'string' && /^[1-9]\d{0,23}$/.test(value) ? value : null;
}
function stockRecord(product) {
  if (!product || typeof product !== 'object') throw new StockError('INVALID_RESPONSE');
  const id = productId(product.vendoritemid);
  if (!id) throw new StockError('INVALID_PRODUCT_ID');
  const quantity = nonnegativeInteger(product.stockQuantity);
  const soldOut = typeof product.isSoldOut === 'boolean' ? product.isSoldOut : null;
  return {vendoritemid: id, stockQuantity: soldOut === true ? 0 : quantity, isSoldOut: soldOut, status: soldOut === null || (soldOut !== true && quantity === null) ? 'INVALID_STOCK' : 'OK'};
}
async function openLogin() {
  try {
    if (loginTabId !== null) {
      try {
        const tab = await chrome.tabs.get(loginTabId);
        if (tab) {
          await chrome.tabs.update(loginTabId, {active: true}); return true;
        }
      } catch (_) { /* closed or navigated away */ }
    }
    const tab = await chrome.tabs.create({url: LOGIN_URL, active: true});
    loginTabId = tab.id; return true;
  } catch (_) { return false; }
}
async function ensureAdsTab(context) {
  if(context.tabId) return context.tabId;
  const candidates=await chrome.tabs.query({url:'https://advertising.coupang.com/*'});
  let tab=candidates.find(t=>t.url&&!t.url.includes('/user/login'))||candidates[0];
  if(!tab){tab=await chrome.tabs.create({url:LOGIN_URL,active:true});loginTabId=tab.id;}
  const until=Date.now()+15000;
  while(tab.status!=='complete'&&Date.now()<until){await new Promise(r=>setTimeout(r,500));tab=await chrome.tabs.get(tab.id);}
  if(!tab.url||new URL(tab.url).origin!=='https://advertising.coupang.com'||tab.url.includes('/user/login'))throw new StockError('LOGIN_REQUIRED');
  context.tabId=tab.id;return tab.id;
}
async function fetchFromAdsTab(url,context){
  const tabId=await ensureAdsTab(context);
  const list=await chrome.scripting.executeScript({target:{tabId},world:'MAIN',func:async u=>{const c=new AbortController();const timer=setTimeout(()=>c.abort(),15000);try{const r=await fetch(u,{credentials:'include',redirect:'manual',cache:'no-store',headers:{Accept:'application/json'},signal:c.signal});const body=await r.text();return {status:r.status,type:r.type,ok:r.ok,contentType:r.headers.get('content-type')||'',body:body.length>1000000?'':body,tooLarge:body.length>1000000};}finally{clearTimeout(timer);}},args:[url]});
  const value=list[0]?.result;if(!value)throw new StockError('LOGIN_REQUIRED');return value;
}
async function fetchPage(query, pageNumber, context) {
  if (Date.now() >= context.deadline) throw new StockError('TIME_LIMIT');
  if (context.pages >= LIMITS.maxPagesTotal) throw new StockError('PAGE_LIMIT');
  const url = new URL(API_URL);
  url.search = new URLSearchParams({page: String(pageNumber), size: String(LIMITS.pageSize), keyword: query, searchBy: 'itemname', isColdStartItem: 'true'}).toString();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), Math.min(LIMITS.fetchTimeoutMs, context.deadline - Date.now()));
  context.pages++;
  try {
    const response = await fetchFromAdsTab(url.href,context);
    if(response.type==='opaqueredirect'||response.status===401||(response.status>=300&&response.status<400))throw new StockError('LOGIN_REQUIRED');
    if(response.status===429)throw new StockError('RATE_LIMITED');
    if(response.status>=500)throw new StockError('UPSTREAM_ERROR');
    if(response.tooLarge)throw new StockError('RESPONSE_TOO_LARGE');
    const body=response.body,contentType=response.contentType;
    if(!contentType.toLowerCase().includes('json')){
      if(/(?:login|sign[ -]?in|로그인)/i.test(body)&&/<(?:html|form|!doctype)/i.test(body))throw new StockError('LOGIN_REQUIRED');
      throw new StockError(response.status===403?'ACCESS_DENIED':'NON_JSON_RESPONSE');
    }
    let data;
    try { data = JSON.parse(body); } catch (_) { throw new StockError('INVALID_JSON'); }
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new StockError('INVALID_RESPONSE');
    const authCode = String(data.code ?? data.errorCode ?? data.error?.code ?? '').toUpperCase();
    if (data.authenticated === false || data.isLoggedIn === false || ['UNAUTHORIZED', 'LOGIN_REQUIRED', 'SESSION_EXPIRED', 'NOT_AUTHENTICATED', '401'].includes(authCode)) throw new StockError('LOGIN_REQUIRED');
    if (!response.ok) throw new StockError(response.status === 403 ? 'ACCESS_DENIED' : 'HTTP_ERROR');
    // Only the observed response contract is accepted. Never forward raw JSON.
    if (!Array.isArray(data.products) || data.products.length > LIMITS.pageSize || data.success === false || data.error) throw new StockError('INVALID_RESPONSE');
    if (data.page !== undefined && nonnegativeInteger(data.page) !== pageNumber) throw new StockError('PAGINATION_MISMATCH');
    if (data.size !== undefined && nonnegativeInteger(data.size) !== LIMITS.pageSize) throw new StockError('PAGINATION_MISMATCH');
    const total = data.total === undefined ? null : nonnegativeInteger(data.total);
    if (data.total !== undefined && total === null) throw new StockError('INVALID_RESPONSE');
    const products = data.products.map(stockRecord);
    context.authenticated = true;
    return {products, total};
  } catch (error) {
    if (error instanceof StockError) throw error;
    if(/cannot access|No tab|No frame|frame.*removed|not allowed|extensions gallery/i.test(String(error.message))) throw new StockError('LOGIN_REQUIRED');
    throw new StockError(controller.signal.aborted ? 'TIMEOUT' : 'NETWORK_OR_COOKIE_ERROR');
  } finally { clearTimeout(timeout); }
}
function emptyResult(query, status) {
  return {query, status, complete: false, products: [], pagesFetched: 0, totalReported: null, checkedAt: new Date().toISOString()};
}
async function collectQuery(query, context) {
  const result = emptyResult(query, 'OK');
  const byId = new Map();
  try {
    for (let pageNumber = 1; pageNumber <= LIMITS.maxPagesPerQuery; pageNumber++) {
      const page = await fetchPage(query, pageNumber, context);
      result.pagesFetched++;
      if (result.totalReported !== null && page.total !== null && result.totalReported !== page.total) throw new StockError('RESULTS_CHANGED');
      if (page.total !== null) result.totalReported = page.total;
      for (const product of page.products) {
        if (byId.has(product.vendoritemid)) throw new StockError('PAGINATION_OVERLAP');
        if (context.products >= LIMITS.maxProductsTotal) throw new StockError('PRODUCT_LIMIT');
        byId.set(product.vendoritemid, product);
        context.products++;
      }
      if (page.total !== null && byId.size > page.total) throw new StockError('PAGINATION_MISMATCH');
      const exhausted = page.products.length < LIMITS.pageSize || (page.total !== null && byId.size === page.total);
      if (exhausted) {
        if (page.total !== null && byId.size !== page.total) throw new StockError('INCOMPLETE_RESPONSE');
        result.complete = true;
        result.status = byId.size === 0 ? 'NO_MATCH' : [...byId.values()].some(p => p.status !== 'OK') ? 'INVALID_STOCK' : 'OK';
        break;
      }
      if (pageNumber === LIMITS.maxPagesPerQuery) throw new StockError('PAGE_LIMIT');
    }
  } catch (error) { result.status = error instanceof StockError ? error.code : 'INTERNAL_ERROR'; }
  result.products = [...byId.values()];
  result.checkedAt = new Date().toISOString();
  return result;
}
async function collect(queries) {
  const context = {pages: 0, products: 0, authenticated: false, deadline: Date.now() + LIMITS.maxDurationMs};
  const results = [];
  const cached = new Map();
  let stopped = null;
  let authStatus = null;
  for (const rawQuery of queries) {
    const query = rawQuery.trim();
    if (stopped) { results.push(emptyResult(query, 'SKIPPED_' + stopped)); continue; }
    if (cached.has(query)) { results.push(cached.get(query)); continue; }
    const previouslyAuthenticated = context.authenticated;
    const result = await collectQuery(query, context);
    if (result.status === 'LOGIN_REQUIRED') {
      result.status = previouslyAuthenticated || result.pagesFetched > 0 ? 'SESSION_EXPIRED' : 'LOGIN_REQUIRED';
      authStatus = result.status;
      stopped = result.status;
    } else if (['RATE_LIMITED', 'ACCESS_DENIED', 'NETWORK_OR_COOKIE_ERROR', 'TIMEOUT', 'UPSTREAM_ERROR', 'PRODUCT_LIMIT', 'TIME_LIMIT'].includes(result.status)) stopped = result.status;
    else if (context.pages >= LIMITS.maxPagesTotal) stopped = 'PAGE_LIMIT';
    cached.set(query, result);
    results.push(result);
  }
  const loginOpened = authStatus ? await openLogin() : false;
  const ok = results.every(r => r.complete && ['OK', 'NO_MATCH'].includes(r.status));
  return {ok, status: authStatus || (ok ? 'OK' : 'PARTIAL_OR_FAILED'), session: authStatus || (context.authenticated ? 'AUTHENTICATED_ENDPOINT' : 'UNVERIFIED'), results, retryAfterLogin: Boolean(authStatus), loginOpened, pagesRequested: context.pages, checkedAt: new Date().toISOString()};
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!validSender(sender)) { sendResponse({ok: false, status: 'FORBIDDEN_ORIGIN'}); return false; }
  if (!message || message.source !== 'yorgo-dashboard' || typeof message.requestId !== 'string' || !/^[A-Za-z0-9_-]{8,96}$/.test(message.requestId)) { sendResponse({ok: false, status: 'INVALID_REQUEST'}); return false; }
  if (message.type === 'YORGO_STOCK_PING') {
    sendResponse({ok: true, status: 'READY', version: chrome.runtime.getManifest().version, limits: LIMITS, session: 'NOT_CHECKED'}); return false;
  }
  if(message.type==='YORGO_ADS_FETCH') {
    const date=message.queries?.[0], today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
    if(!/^\d{4}-\d{2}-\d{2}$/.test(date||'')||date>today){sendResponse({ok:false,status:'INVALID_DATE'});return false;}
    if(busy){sendResponse({ok:false,status:'BUSY'});return false;}busy=true;
    (async()=>{
      const url='https://advertising.coupang.com/marketing/dashboard/sales';
      let tab=(await chrome.tabs.query({url}))[0];
      if(!tab)tab=await chrome.tabs.create({url,active:false});
      const until=Date.now()+20000;while(tab.status!=='complete'&&Date.now()<until){await new Promise(r=>setTimeout(r,300));tab=await chrome.tabs.get(tab.id);}
      const out=await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:collectAdsDay,args:[date,today]});
      if(!out[0]?.result)throw Error('광고 결과를 확인하지 못했습니다.');return {ok:true,status:'OK',day:out[0].result};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,status:'ADS_FAILED',message:String(e.message||e)})).finally(()=>{busy=false;});return true;
  }
  if (message.type !== 'YORGO_STOCK_FETCH') { sendResponse({ok: false, status: 'INVALID_ACTION'}); return false; }
  if (!validQueries(message.queries)) { sendResponse({ok: false, status: 'INVALID_QUERIES'}); return false; }
  if (busy) { sendResponse({ok: false, status: 'BUSY'}); return false; }
  if (Date.now() - lastStarted < 5000) { sendResponse({ok: false, status: 'RATE_LIMITED', retryAfterMs: 5000}); return false; }
  busy = true;
  lastStarted = Date.now();
  collect(message.queries).then(sendResponse).catch(() => sendResponse({ok: false, status: 'INTERNAL_ERROR'})).finally(() => { busy = false; });
  return true;
});
